
class Converter:

    def convert_data(self, *args):
        pass