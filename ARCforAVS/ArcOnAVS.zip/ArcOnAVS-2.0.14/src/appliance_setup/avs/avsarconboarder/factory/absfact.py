
class ArcAbsFactory:
    def build_factory(self, *args):
        pass

    def retrieve_instance(self, *args):
        pass