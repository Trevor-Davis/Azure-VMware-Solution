
class Orchestrator:
    def orchestrate(self, *args):
        pass