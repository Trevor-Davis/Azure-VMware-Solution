from dataclasses import dataclass


@dataclass
class DHCPData:
    ip_cidr: str