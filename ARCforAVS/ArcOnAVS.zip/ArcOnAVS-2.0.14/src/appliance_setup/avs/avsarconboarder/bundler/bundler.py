
class Bundler:

    def bundle_data(self, *args):
        pass