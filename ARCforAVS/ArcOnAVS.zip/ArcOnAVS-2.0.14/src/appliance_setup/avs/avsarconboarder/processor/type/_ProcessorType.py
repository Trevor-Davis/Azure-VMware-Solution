import enum


class ProcessorType(enum.Enum):
    dhcp = 0
    segment = 1
    dns = 3
