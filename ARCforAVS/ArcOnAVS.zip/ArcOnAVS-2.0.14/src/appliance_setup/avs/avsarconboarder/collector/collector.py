
class Collector:

    def collect_data(self, *args):
        pass