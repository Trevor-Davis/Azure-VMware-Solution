
class Deleter:
    def delete(self, *args):
        raise NotImplementedError("delete function not implemented ")
        pass