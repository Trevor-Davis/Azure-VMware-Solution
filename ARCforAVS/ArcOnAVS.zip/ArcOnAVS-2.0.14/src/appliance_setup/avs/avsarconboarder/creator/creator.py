
class Creator:
    def create(self, *args):
        raise NotImplementedError("create function not implemented ")
        pass