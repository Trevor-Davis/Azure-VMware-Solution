
class Retriever:
    def retrieve_data(self, object):
        raise NotImplementedError(" function not implemented ")
        pass