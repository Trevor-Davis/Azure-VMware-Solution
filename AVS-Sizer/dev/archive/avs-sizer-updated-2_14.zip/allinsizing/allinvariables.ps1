$global:totalVMCount = $importsizer[0].Value
$global:vCpuPerVM = $importsizer[1].Value
$global:storagePerVM = $importsizer[3].Value*1000
$global:vRamPerVM = $importsizer[5].Value