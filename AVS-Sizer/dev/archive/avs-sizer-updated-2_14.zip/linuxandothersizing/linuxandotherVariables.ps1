$global:totalVMCount = $importsizer[42].Value
$global:vCpuPerVM = $importsizer[43].Value
$global:storagePerVM = $importsizer[45].Value*1000
$global:vRamPerVM = $importsizer[47].Value
