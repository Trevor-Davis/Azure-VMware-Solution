$global:totalVMCount = $importsizer[7].Value
$global:vCpuPerVM = $importsizer[8].Value
$global:storagePerVM = $importsizer[10].Value*1000
$global:vRamPerVM = $importsizer[12].Value
