
$global:apiurl = "https://vmc.vmware.com/api/vmc-sizer/v5/recommendation?vmPlacement=false"
$global:apiurlstaging = "https://stg.skyscraper.vmware.com/api/vmc-sizer/v5/recommendation"
$global:filename = "sizer.xlsm" # this is the filename of the sizer file
$global:buttonclicked = ""

