$global:totalVMCount = $importsizer[14].Value
$global:vCpuPerVM = $importsizer[15].Value
$global:storagePerVM = $importsizer[17].Value*1000
$global:vRamPerVM = $importsizer[19].Value
